# Android 移植状态

## 本次已经写入源码的部分

- [x] Android Studio / Gradle 工程骨架
- [x] ARM64 `arm64-v8a` 构建配置
- [x] Android NDK Vulkan header 查找补丁
- [x] 复用现有 SpektraLab C++20 Vulkan 引擎 target
- [x] JNI 接入原始 C ABI：engine create/destroy、open、set/get params、render、close
- [x] SPIR-V 与 engine/resources 的 APK assets staging 规则
- [x] Android 照片选择器、Bitmap -> float32 RGB 输入
- [x] 胶片/相纸 profile 列表读取
- [x] Grain / Halation / Glare / exposure 参数 UI
- [x] 预览与 JPEG 导出流程

## 仍需在开发电脑/真机完成

- [ ] 安装 Android SDK/NDK 和 host glslangValidator
- [ ] Gradle Sync 与 CMake configure
- [ ] 修复真实 NDK 编译器报告的兼容问题
- [ ] 在 OPPO Find N6 上验证 Vulkan loader / compute queue / storage buffer limits
- [ ] 用测试照片与 Mac/Windows Vulkan 输出比较色彩差异
- [ ] 性能、温度、内存和大图稳定性测试
- [ ] LibRaw Android 移植
- [ ] 16-bit TIFF / ICC 导出
- [ ] 完整 UI、更多上游功能与所有参数接入

## 不要误读

本次交付是“基于真实引擎的 Android 移植工程”，不是已经编译和真机验证的 APK。当前环境没有 Android SDK/NDK 与 Vulkan host shader compiler，因此不能在这里诚实地宣称 APK 已经构建成功。
