plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val generatedSpekAssets = layout.buildDirectory.dir("generated/spektraAssets")
val glslangPath = providers.gradleProperty("glslangValidator").orNull

android {
    namespace = "com.spektralab.android"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.spektralab.android"
        minSdk = 28
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-android-port"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DSPEKTRALAB_REQUIRE_VULKAN=ON",
                    "-DSPEKTRALAB_BUILD_NATIVE_RAW=OFF",
                    "-DSPEKTRALAB_BUILD_HOST=OFF",
                    "-DSPEKTRALAB_BUILD_DESKTOP=OFF",
                    "-DSPEKTRALAB_BUILD_TEST_DLL=OFF",
                    "-DSPEKTRALAB_ANDROID_ASSET_DIR=${generatedSpekAssets.get().asFile.absolutePath}"
                )
                if (!glslangPath.isNullOrBlank()) {
                    arguments += "-DSPEKTRALAB_GLSLANG=$glslangPath"
                }
                cppFlags += listOf("-std=c++20")
            }
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    sourceSets {
        getByName("main").assets.srcDir(generatedSpekAssets)
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }
}

// The CMake ALL target stages the original engine resources and compiled
// SPIR-V kernels. Make sure that stage exists before Gradle merges APK assets.
tasks.configureEach {
    when (name) {
        "mergeDebugAssets" -> dependsOn("externalNativeBuildDebug")
        "mergeReleaseAssets" -> dependsOn("externalNativeBuildRelease")
    }
}
