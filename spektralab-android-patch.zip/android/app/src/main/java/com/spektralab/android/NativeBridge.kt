package com.spektralab.android

class NativeBridge {
    companion object {
        init {
            System.loadLibrary("spektralab_android")
        }
    }

    external fun nativeCreateEngine(resourcesDir: String): Long
    external fun nativeDestroyEngine(engine: Long)
    external fun nativeLastError(engine: Long): String
    external fun nativeCapabilities(engine: Long): String
    external fun nativeParamsSchema(engine: Long): String

    external fun nativeOpenFrame(
        engine: Long,
        rgb: FloatArray,
        width: Int,
        height: Int,
        paramsJson: String
    ): Long

    external fun nativeSetParams(session: Long, paramsJson: String): Int
    external fun nativeGetParams(session: Long): String?
    // Returns [width, height, ARGB_8888 pixel 0, pixel 1, ...].
    external fun nativeRender(session: Long, tier: String, useReprint: Boolean): IntArray?
    external fun nativeCloseSession(session: Long)
}
