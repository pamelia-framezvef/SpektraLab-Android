package com.spektralab.android

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    companion object {
        private const val PICK_IMAGE = 1101
        private const val PREVIEW_LONG_EDGE = 2048
    }

    private data class Stock(val id: String, val title: String)

    private val worker = Executors.newSingleThreadExecutor()
    private val bridge by lazy { NativeBridge() }

    private var engineHandle = 0L
    private var sessionHandle = 0L
    private var sourceBitmap: Bitmap? = null
    private var lastRenderedBitmap: Bitmap? = null
    private var filmStocks: List<Stock> = emptyList()
    private var printStocks: List<Stock> = emptyList()

    private lateinit var statusText: TextView
    private lateinit var imageView: ImageView
    private lateinit var filmSpinner: Spinner
    private lateinit var printSpinner: Spinner
    private lateinit var grainSwitch: Switch
    private lateinit var halationSwitch: Switch
    private lateinit var glareSwitch: Switch
    private lateinit var exposureText: TextView
    private lateinit var exposureSeek: SeekBar
    private lateinit var renderButton: Button
    private lateinit var exportButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initialiseEngine()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setBackgroundColor(Color.rgb(25, 29, 30))
        }

        val title = TextView(this).apply {
            text = "SpektraLab"
            textSize = 27f
            setTextColor(Color.rgb(244, 239, 228))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "ANDROID · 原版 C++ / Vulkan 引擎移植验证版"
            textSize = 11f
            setTextColor(Color.rgb(196, 164, 111))
            setPadding(0, dp(3), 0, dp(8))
        }
        root.addView(subtitle)

        statusText = TextView(this).apply {
            text = "正在准备原版引擎资源……"
            textSize = 12f
            setTextColor(Color.rgb(196, 205, 198))
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(statusText)

        imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setBackgroundColor(Color.rgb(10, 12, 13))
            contentDescription = "照片预览"
        }
        root.addView(
            imageView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { bottomMargin = dp(10) }
        )

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val importButton = button("导入照片") { choosePhoto() }
        controls.addView(importButton, matchHeight(dp(46)))

        controls.addView(label("胶片"))
        filmSpinner = Spinner(this)
        controls.addView(filmSpinner, matchHeight(dp(48)))

        controls.addView(label("放大相纸"))
        printSpinner = Spinner(this)
        controls.addView(printSpinner, matchHeight(dp(48)))

        grainSwitch = Switch(this).apply {
            text = "胶片颗粒 Grain"
            setTextColor(Color.WHITE)
            isChecked = true
        }
        controls.addView(grainSwitch, matchHeight(dp(46)))

        halationSwitch = Switch(this).apply {
            text = "胶片光晕 Halation"
            setTextColor(Color.WHITE)
            isChecked = true
        }
        controls.addView(halationSwitch, matchHeight(dp(46)))

        glareSwitch = Switch(this).apply {
            text = "放大眩光 Glare"
            setTextColor(Color.WHITE)
            isChecked = true
        }
        controls.addView(glareSwitch, matchHeight(dp(46)))

        exposureText = label("曝光补偿：0.0 EV")
        controls.addView(exposureText)
        exposureSeek = SeekBar(this).apply {
            max = 160
            progress = 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val ev = (progress - 80) / 10.0
                    exposureText.text = "曝光补偿：${"%.1f".format(ev)} EV"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(exposureSeek, matchHeight(dp(42)))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        renderButton = button("应用设置并渲染") { renderCurrent() }
        exportButton = button("导出 JPEG") { exportCurrent() }.apply { isEnabled = false }
        actions.addView(renderButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            rightMargin = dp(5)
        })
        actions.addView(exportButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            leftMargin = dp(5)
        })
        controls.addView(actions)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(controls)
        }
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(330)
        ))

        setContentView(root)
        renderButton.isEnabled = false
        exportButton.isEnabled = false
    }

    private fun initialiseEngine() {
        setStatus("正在复制胶片配置和 Vulkan 着色器……")
        worker.execute {
            try {
                val resources = File(filesDir, "spektralab-resources")
                copyAssetTree("resources", resources)
                val created = bridge.nativeCreateEngine(resources.absolutePath)
                if (created == 0L) {
                    throw IllegalStateException(bridge.nativeLastError(0L).ifBlank {
                        "原生引擎创建失败"
                    })
                }
                engineHandle = created
                val caps = bridge.nativeCapabilities(engineHandle)
                loadStockCatalogues()
                runOnUiThread {
                    installStockAdapters()
                    renderButton.isEnabled = sourceBitmap != null
                    statusText.text = "Vulkan 引擎已初始化。${summariseCapabilities(caps)}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "引擎初始化失败：${e.message ?: "未知错误"}"
                    Toast.makeText(this, "请检查 Vulkan GPU 和着色器编译环境", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = assets.list(assetPath)
        if (children != null && children.isNotEmpty()) {
            destination.mkdirs()
            for (child in children) {
                copyAssetTree("$assetPath/$child", File(destination, child))
            }
        } else {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }

    private fun loadStockCatalogues() {
        val names = assets.list("resources/profiles") ?: emptyArray()
        val films = mutableListOf<Stock>()
        val papers = mutableListOf<Stock>()
        for (fileName in names.filter { it.endsWith(".json") }) {
            try {
                val json = assets.open("resources/profiles/$fileName")
                    .bufferedReader().use { it.readText() }
                val info = JSONObject(json).getJSONObject("info")
                val stock = Stock(
                    info.optString("stock", fileName.removeSuffix(".json")),
                    info.optString("name", fileName.removeSuffix(".json"))
                )
                when (info.optString("stage")) {
                    "filming" -> films.add(stock)
                    "printing" -> papers.add(stock)
                }
            } catch (_: Exception) {
                // Ignore malformed or non-stock JSON; the engine validates the chosen id.
            }
        }
        filmStocks = films.sortedBy { it.title.lowercase() }
        printStocks = papers.sortedBy { it.title.lowercase() }
    }

    private fun installStockAdapters() {
        fun adapter(items: List<Stock>, selectedId: String): ArrayAdapter<String> {
            val labels = items.map { "${it.title}  (${it.id})" }
            val result = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
            result.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            return result
        }
        filmSpinner.adapter = adapter(filmStocks, "kodak_portra_400")
        printSpinner.adapter = adapter(printStocks, "kodak_portra_endura")
        filmStocks.indexOfFirst { it.id == "kodak_portra_400" }.takeIf { it >= 0 }?.let {
            filmSpinner.setSelection(it)
        }
        printStocks.indexOfFirst { it.id == "kodak_portra_endura" }.takeIf { it >= 0 }?.let {
            printSpinner.setSelection(it)
        }
    }

    private fun summariseCapabilities(json: String): String {
        return try {
            val root = JSONObject(json)
            val backend = root.optJSONObject("backend")
            val name = backend?.optString("render_core", "Vulkan") ?: "Vulkan"
            "后端：$name"
        } catch (_: Exception) {
            "后端：Vulkan"
        }
    }

    private fun choosePhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, PICK_IMAGE)
    }

    @Deprecated("Uses ACTION_OPEN_DOCUMENT for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        decodeAndOpen(uri)
    }

    private fun decodeAndOpen(uri: Uri) {
        setStatus("正在读取照片……")
        worker.execute {
            try {
                val source = ImageDecoder.createSource(contentResolver, uri)
                val bitmap = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val maxEdge = max(info.size.width, info.size.height)
                    if (maxEdge > PREVIEW_LONG_EDGE) {
                        val scale = PREVIEW_LONG_EDGE.toFloat() / maxEdge.toFloat()
                        decoder.setTargetSize(
                            (info.size.width * scale).roundToInt().coerceAtLeast(1),
                            (info.size.height * scale).roundToInt().coerceAtLeast(1)
                        )
                    }
                }.copy(Bitmap.Config.ARGB_8888, false)

                if (engineHandle == 0L) throw IllegalStateException("引擎尚未初始化")
                val oldSession = sessionHandle
                if (oldSession != 0L) {
                    bridge.nativeCloseSession(oldSession)
                    sessionHandle = 0L
                }

                val pixels = IntArray(bitmap.width * bitmap.height)
                bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                val rgb = FloatArray(pixels.size * 3)
                for (i in pixels.indices) {
                    val p = pixels[i]
                    rgb[i * 3] = Color.red(p) / 255f
                    rgb[i * 3 + 1] = Color.green(p) / 255f
                    rgb[i * 3 + 2] = Color.blue(p) / 255f
                }

                val opened = bridge.nativeOpenFrame(
                    engineHandle, rgb, bitmap.width, bitmap.height, buildOpenParams()
                )
                if (opened == 0L) {
                    throw IllegalStateException(bridge.nativeLastError(engineHandle))
                }
                sessionHandle = opened
                sourceBitmap = bitmap
                runOnUiThread {
                    imageView.setImageBitmap(bitmap)
                    renderButton.isEnabled = true
                    exportButton.isEnabled = false
                    setStatus("照片已载入：${bitmap.width} × ${bitmap.height}。点击「应用设置并渲染」。")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("照片导入失败：${e.message ?: "未知错误"}")
                    Toast.makeText(this, "无法打开该照片", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun buildOpenParams(): String {
        val film = filmStocks.getOrNull(filmSpinner.selectedItemPosition)?.id ?: "kodak_portra_400"
        val paper = printStocks.getOrNull(printSpinner.selectedItemPosition)?.id ?: "kodak_portra_endura"
        return JSONObject().apply {
            put("film_stock", film)
            put("print_stock", paper)
            put("input_color_space", "sRGB")
            put("input_cctf_decoding", true)
            put("output_color_space", "sRGB")
            put("output_cctf_encoding", true)
            put("grain_active", grainSwitch.isChecked)
            put("halation_active", halationSwitch.isChecked)
            put("glare_active", glareSwitch.isChecked)
            put("exposure_compensation_ev", (exposureSeek.progress - 80) / 10.0)
        }.toString()
    }

    private fun buildEditParams(): String {
        val film = filmStocks.getOrNull(filmSpinner.selectedItemPosition)?.id ?: "kodak_portra_400"
        val paper = printStocks.getOrNull(printSpinner.selectedItemPosition)?.id ?: "kodak_portra_endura"
        return JSONObject().apply {
            put("film_stock", film)
            put("print_stock", paper)
            put("grain_active", grainSwitch.isChecked)
            put("halation_active", halationSwitch.isChecked)
            put("glare_active", glareSwitch.isChecked)
            put("exposure_compensation_ev", (exposureSeek.progress - 80) / 10.0)
        }.toString()
    }

    private fun renderCurrent() {
        if (engineHandle == 0L) {
            setStatus("引擎尚未就绪")
            return
        }
        if (sessionHandle == 0L) {
            setStatus("请先导入一张照片")
            return
        }
        renderButton.isEnabled = false
        exportButton.isEnabled = false
        setStatus("正在调用原版胶片 / 相纸模拟管线……")
        worker.execute {
            try {
                val status = bridge.nativeSetParams(sessionHandle, buildEditParams())
                if (status != 0) throw IllegalStateException(
                    "参数更新失败（$status）：${bridge.nativeLastError(engineHandle)}"
                )
                val data = bridge.nativeRender(sessionHandle, "preview", false)
                    ?: throw IllegalStateException(bridge.nativeLastError(engineHandle).ifBlank {
                        "Vulkan 预览渲染失败"
                    })
                val bitmap = bitmapFromNative(data)
                lastRenderedBitmap = bitmap
                runOnUiThread {
                    imageView.setImageBitmap(bitmap)
                    renderButton.isEnabled = true
                    exportButton.isEnabled = true
                    setStatus("渲染完成：${bitmap.width} × ${bitmap.height}。")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    renderButton.isEnabled = true
                    setStatus("渲染失败：${e.message ?: "未知错误"}")
                }
            }
        }
    }

    private fun bitmapFromNative(data: IntArray): Bitmap {
        require(data.size >= 2) { "引擎返回的数据不完整" }
        val width = data[0]
        val height = data[1]
        require(width > 0 && height > 0 && data.size == width * height + 2) {
            "引擎返回的图像尺寸不合法"
        }
        return Bitmap.createBitmap(
            data, 2, width, width, height, Bitmap.Config.ARGB_8888
        )
    }

    private fun exportCurrent() {
        if (sessionHandle == 0L) return
        renderButton.isEnabled = false
        exportButton.isEnabled = false
        setStatus("正在进行 full 级别渲染并导出 JPEG……")
        worker.execute {
            try {
                val data = bridge.nativeRender(sessionHandle, "full", false)
                    ?: throw IllegalStateException(bridge.nativeLastError(engineHandle).ifBlank {
                        "全尺寸渲染失败"
                    })
                val bitmap = bitmapFromNative(data)
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "SpektraLab_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/SpektraLab"
                    )
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("无法创建相册文件")
                contentResolver.openOutputStream(uri)?.use { output ->
                    if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 97, output)) {
                        throw IllegalStateException("JPEG 编码失败")
                    }
                } ?: throw IllegalStateException("无法写入相册")
                val done = ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                }
                contentResolver.update(uri, done, null, null)
                runOnUiThread {
                    renderButton.isEnabled = true
                    exportButton.isEnabled = true
                    setStatus("已导出到 Pictures/SpektraLab。当前导出格式为 JPEG。")
                    Toast.makeText(this, "导出完成", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    renderButton.isEnabled = true
                    exportButton.isEnabled = true
                    setStatus("导出失败：${e.message ?: "未知错误"}")
                }
            }
        }
    }

    private fun copyAssetTreeSafe() {
        // Kept as a named helper for future incremental asset-copy checks.
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(229, 224, 211))
        setPadding(0, dp(8), 0, dp(3))
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 13f
            setOnClickListener { action() }
        }

    private fun matchHeight(height: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, height
    )

    private fun setStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        if (sessionHandle != 0L) {
            bridge.nativeCloseSession(sessionHandle)
            sessionHandle = 0L
        }
        if (engineHandle != 0L) {
            bridge.nativeDestroyEngine(engineHandle)
            engineHandle = 0L
        }
        worker.shutdown()
        super.onDestroy()
    }
}
