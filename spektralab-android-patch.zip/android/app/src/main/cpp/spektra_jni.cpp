#include <jni.h>

#include <cstdint>
#include <limits>
#include <string>
#include <vector>

#include "spektrafilm/spk_engine.h"

namespace {

template <typename T>
T* from_handle(jlong handle) {
    return reinterpret_cast<T*>(static_cast<uintptr_t>(handle));
}

template <typename T>
jlong to_handle(T* pointer) {
    return static_cast<jlong>(reinterpret_cast<uintptr_t>(pointer));
}

std::string from_java(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

jstring to_java(JNIEnv* env, const char* value) {
    return env->NewStringUTF(value ? value : "");
}

uint32_t unorm16_to_unorm8(uint16_t value) {
    return (uint32_t(value) * 255u + 32767u) / 65535u;
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_spektralab_android_NativeBridge_nativeCreateEngine(
        JNIEnv* env, jobject, jstring resources_dir) {
    const std::string path = from_java(env, resources_dir);
    if (path.empty()) return 0;
    spk_engine* engine = spk_engine_create(path.c_str(), nullptr);
    return to_handle(engine);
}

JNIEXPORT void JNICALL
Java_com_spektralab_android_NativeBridge_nativeDestroyEngine(
        JNIEnv*, jobject, jlong engine_handle) {
    if (auto* engine = from_handle<spk_engine>(engine_handle))
        spk_engine_destroy(engine);
}

JNIEXPORT jstring JNICALL
Java_com_spektralab_android_NativeBridge_nativeLastError(
        JNIEnv* env, jobject, jlong engine_handle) {
    return to_java(env, spk_last_error(from_handle<spk_engine>(engine_handle)));
}

JNIEXPORT jstring JNICALL
Java_com_spektralab_android_NativeBridge_nativeCapabilities(
        JNIEnv* env, jobject, jlong engine_handle) {
    auto* engine = from_handle<spk_engine>(engine_handle);
    return to_java(env, engine ? spk_capabilities(engine) : nullptr);
}

JNIEXPORT jstring JNICALL
Java_com_spektralab_android_NativeBridge_nativeParamsSchema(
        JNIEnv* env, jobject, jlong engine_handle) {
    auto* engine = from_handle<spk_engine>(engine_handle);
    return to_java(env, engine ? spk_params_schema(engine) : nullptr);
}

JNIEXPORT jlong JNICALL
Java_com_spektralab_android_NativeBridge_nativeOpenFrame(
        JNIEnv* env, jobject, jlong engine_handle, jfloatArray rgb_array,
        jint width, jint height, jstring params_json) {
    auto* engine = from_handle<spk_engine>(engine_handle);
    if (!engine || !rgb_array || width <= 0 || height <= 0) return 0;

    const uint64_t pixels = uint64_t(width) * uint64_t(height);
    if (pixels > uint64_t(std::numeric_limits<jsize>::max()) / 3u ||
        pixels > uint64_t(std::numeric_limits<size_t>::max()) / (3u * sizeof(float)) ||
        env->GetArrayLength(rgb_array) != jsize(pixels * 3u)) {
        return 0;
    }

    jfloat* rgb = env->GetFloatArrayElements(rgb_array, nullptr);
    if (!rgb) return 0;

    spk_image input{};
    input.data = rgb;
    input.width = uint32_t(width);
    input.height = uint32_t(height);
    input.channels = 3;

    const std::string params = from_java(env, params_json);
    char* reply = nullptr;
    spk_session* session = spk_open(
        engine, &input, params.empty() ? nullptr : params.c_str(), &reply);

    if (reply) spk_string_free(reply);
    env->ReleaseFloatArrayElements(rgb_array, rgb, JNI_ABORT);
    return to_handle(session);
}

JNIEXPORT jint JNICALL
Java_com_spektralab_android_NativeBridge_nativeSetParams(
        JNIEnv* env, jobject, jlong session_handle, jstring params_json) {
    auto* session = from_handle<spk_session>(session_handle);
    if (!session || !params_json) return SPK_ERR_INVALID_ARG;

    const std::string params = from_java(env, params_json);
    if (params.empty()) return SPK_ERR_INVALID_ARG;

    char* reply = nullptr;
    const spk_status status = spk_set_params(session, params.c_str(), &reply);
    if (reply) spk_string_free(reply);
    return jint(status);
}

JNIEXPORT jstring JNICALL
Java_com_spektralab_android_NativeBridge_nativeGetParams(
        JNIEnv* env, jobject, jlong session_handle) {
    auto* session = from_handle<spk_session>(session_handle);
    if (!session) return nullptr;

    char* reply = nullptr;
    const spk_status status = spk_get_params(session, &reply);
    if (status != SPK_OK) {
        if (reply) spk_string_free(reply);
        return nullptr;
    }

    jstring result = to_java(env, reply);
    if (reply) spk_string_free(reply);
    return result;
}

JNIEXPORT jintArray JNICALL
Java_com_spektralab_android_NativeBridge_nativeRender(
        JNIEnv* env, jobject, jlong session_handle, jstring tier_name,
        jboolean use_reprint) {
    auto* session = from_handle<spk_session>(session_handle);
    const std::string tier = from_java(env, tier_name);
    if (!session || tier.empty()) return nullptr;

    spk_result result{};
    const spk_status status = use_reprint == JNI_TRUE
        ? spk_reprint(session, tier.c_str(), &result)
        : spk_render(session, tier.c_str(), &result);

    if (status != SPK_OK || !result.rgba16 || result.width == 0 ||
        result.height == 0 || result.row_stride_px < result.width) {
        spk_result_free(&result);
        return nullptr;
    }

    const uint64_t pixel_count = uint64_t(result.width) * result.height;
    if (pixel_count > uint64_t(std::numeric_limits<jsize>::max() - 2) ||
        pixel_count > uint64_t(std::numeric_limits<size_t>::max() / sizeof(jint))) {
        spk_result_free(&result);
        return nullptr;
    }

    std::vector<jint> output;
    try {
        output.resize(size_t(pixel_count) + 2u);
    } catch (...) {
        spk_result_free(&result);
        return nullptr;
    }

    output[0] = jint(result.width);
    output[1] = jint(result.height);

    for (uint32_t y = 0; y < result.height; ++y) {
        for (uint32_t x = 0; x < result.width; ++x) {
            const size_t source =
                (size_t(y) * result.row_stride_px + x) * 4u;
            const uint32_t r = unorm16_to_unorm8(result.rgba16[source + 0]);
            const uint32_t g = unorm16_to_unorm8(result.rgba16[source + 1]);
            const uint32_t b = unorm16_to_unorm8(result.rgba16[source + 2]);
            const uint32_t a = unorm16_to_unorm8(result.rgba16[source + 3]);
            output[2u + size_t(y) * result.width + x] =
                jint((a << 24u) | (r << 16u) | (g << 8u) | b);
        }
    }

    jintArray array = env->NewIntArray(jsize(output.size()));
    if (array) {
        env->SetIntArrayRegion(array, 0, jsize(output.size()), output.data());
        if (env->ExceptionCheck()) array = nullptr;
    }

    spk_result_free(&result);
    return array;
}

JNIEXPORT void JNICALL
Java_com_spektralab_android_NativeBridge_nativeCloseSession(
        JNIEnv*, jobject, jlong session_handle) {
    if (auto* session = from_handle<spk_session>(session_handle))
        spk_session_release(session);
}

}  // extern "C"
