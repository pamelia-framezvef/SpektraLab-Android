# SpektraLab Android Vulkan 移植工程（0.2.0）

## 当前版本是什么

这是在用户上传的 SpektraLab 源码上增加的 Android Studio 工程，开始调用上游的 C++20 / Vulkan 图像处理引擎；不是用 RGB 滤镜假装原版光谱胶片模型。

Android 工程包含：
- ARM64 Android 应用模块；
- CMake 将原项目 `engine/` 编译为 JNI 可调用的原生库；
- JNI 调用 `spk_engine_create`、`spk_open`、`spk_set_params`、`spk_render` / `spk_reprint` 等原始 C ABI；
- Vulkan GLSL 着色器在构建电脑上由 `glslangValidator` 编译成 SPIR-V；
- 将 `engine/resources` 和生成的 `resources/vulkan/*.spv` 打包进 APK；
- 首次启动时把资源复制到应用私有目录，供引擎按文件路径和 mmap 读取；
- 从 Android 照片选择器导入 JPEG/PNG 等系统可解码图片；
- 选择原项目自带的胶片与相纸配置；
- 调整颗粒、Halation、Glare 和曝光补偿；
- 使用原生引擎预览渲染，并导出 JPEG。

## 尚未完成的部分

必须如实区分 Android 移植和 macOS 完整产品：

1. Android 目前使用系统 Bitmap 解码普通图片；LibRaw 尚未编入 Android，因此这版还不能直接解码 RAW。
2. 当前 Android UI 仅接入一组基础参数，未复刻 macOS 的完整编辑面板、半格工作流、胶片边框和所有导出选项。
3. 原项目 `engine/PORT_COVERAGE.md` 明确记录了 Vulkan/非 Apple 后端仍拒绝部分功能，包括对比蒙版、场景宽容度映射的应用、Cineon DI、overscan/film edge 和 date imprint。Android 复用该后端，不会自动获得这些 Mac 专属能力。
4. 原项目 `engine/WINDOWS_FEATURE_COVERAGE.md` 说明全图 Metal/Python 胶片模型 parity 尚未完成证明。Android 真机仍须用参考图像做数值与视觉一致性测试。
5. 当前 JNI 将 RGBA16 引擎结果转换成 Android ARGB_8888 Bitmap，因此 APK 里的 JPEG 导出为 8-bit JPEG，不是 16-bit TIFF。
6. 本工程尚未在 OPPO Find N6 / Android 17 真机编译、运行和性能验证；构建电脑必须安装 Android SDK/NDK、CMake 和 Vulkan SDK 的 host `glslangValidator`。

## 构建环境

推荐在 macOS / Windows / Linux 电脑上使用 Android Studio：

- Android Studio（支持 AGP 8.7.3）
- JDK 17
- Android SDK Platform 35
- Android NDK `27.2.12479018`
- CMake `3.22.1`
- Ninja（Android Studio CMake 工具链通常会安装）
- Vulkan SDK（需要 host 端 `glslangValidator`）
- Android 设备至少 Android 8.0 / API 26；Vulkan compute 驱动必须存在且满足引擎的设备限制。

## macOS 构建步骤

1. 安装 Android Studio，并在 SDK Manager 安装 Android SDK 35、NDK 27.2.12479018、CMake 3.22.1。
2. 安装 LunarG Vulkan SDK，确认终端能找到 `glslangValidator`。也可以在构建时显式传入它的绝对路径。
3. 用 Android Studio 打开本目录 `android/`。
4. 等待 Gradle Sync。
5. 选择 `app` 配置和 `arm64-v8a` 设备。
6. Build > Build Bundle(s) / APK(s) > Build APK(s)。
7. APK 通常位于 `android/app/build/outputs/apk/debug/app-debug.apk`。
8. 安装到 OPPO Find N6，启动后检查 Vulkan 引擎状态，再导入一张普通 JPEG 测试。

如果从终端构建，并且 `glslangValidator` 不在 PATH：

```bash
cd android
gradle assembleDebug -PglslangValidator=/绝对路径/glslangValidator
```

## 常见错误

- `Vulkan headers ... glslangValidator are required`：NDK Vulkan headers 或 host `glslangValidator` 没找到。
- `no Vulkan loader found` / `no Vulkan physical device`：系统 Vulkan loader 或 GPU 驱动不可用。
- `Vulkan device limits are below the current shader layout`：设备的 compute / storage-buffer 限制达不到当前后端要求。
- `missing resource`：APK 资源没有成功 stage；确认 `externalNativeBuildDebug` 在 `mergeDebugAssets` 之前完成。
- `unsupported`：当前上游 Vulkan 后端明确拒绝的功能，不是 Android UI 错误。

## 许可与上游

本工程基于用户提供的 SpektraLab 源码归档。移植、修改和分发时必须遵守仓库根目录 `LICENSE.txt`、相关资源目录的 NOTICE/许可，以及上游第三方组件各自的许可要求。不要移除原始版权与许可文件。
