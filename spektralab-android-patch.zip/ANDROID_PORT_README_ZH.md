# Android 移植入口

Android Studio 工程位于 [`android/`](android/)。

构建环境、当前接入范围、限制与真机测试步骤见 [`android/README_ANDROID_ZH.md`](android/README_ANDROID_ZH.md)。

这是源码移植工程，尚未在 OPPO Find N6 上构建或验证，不是现成 APK。
